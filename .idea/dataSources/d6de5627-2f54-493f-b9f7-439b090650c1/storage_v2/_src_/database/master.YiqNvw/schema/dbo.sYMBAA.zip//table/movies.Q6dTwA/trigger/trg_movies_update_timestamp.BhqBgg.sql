CREATE TRIGGER trg_movies_update_timestamp
ON movies
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE movies
    SET updateDate = GETDATE()
    WHERE Id_movies IN (SELECT Id_movies FROM INSERTED);
END;
go

