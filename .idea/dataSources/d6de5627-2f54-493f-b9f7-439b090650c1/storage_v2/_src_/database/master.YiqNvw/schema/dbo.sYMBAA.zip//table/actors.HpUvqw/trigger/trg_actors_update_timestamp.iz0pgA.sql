CREATE TRIGGER trg_actors_update_timestamp
ON actors
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE actors
    SET updateDate = GETDATE()
    WHERE Id_actors IN (SELECT Id_actors FROM INSERTED);
END;
go

